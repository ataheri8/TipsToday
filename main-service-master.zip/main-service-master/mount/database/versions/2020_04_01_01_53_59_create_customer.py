"""create_customer

Revision ID: b7bb9ffe22f7
Revises: 624c73381210
Create Date: 2020-04-01 01:53:59.904234

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b7bb9ffe22f7'
down_revision = '624c73381210'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass