"""empty message

Revision ID: e72c4d960da8
Revises: a95364cde997, 6524305ed1cc
Create Date: 2020-04-20 15:40:59.123356

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e72c4d960da8'
down_revision = ('a95364cde997', '6524305ed1cc')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
