"""empty message

Revision ID: b587a2d0d263
Revises: b35ca07d32db, e72c4d960da8
Create Date: 2020-04-27 17:15:33.146811

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b587a2d0d263'
down_revision = ('b35ca07d32db', 'e72c4d960da8')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
